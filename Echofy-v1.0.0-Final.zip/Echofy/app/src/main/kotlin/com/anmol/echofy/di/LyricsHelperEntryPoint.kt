/*
 * Echofy - by Anmol
 * Anmol Srivastava
 * Licensed Under GPL-3.0
 */



package com.anmol.echofy.di

import com.anmol.echofy.lyrics.LyricsHelper
import com.anmol.echofy.lyrics.LyricsPreloadManager
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@EntryPoint
@InstallIn(SingletonComponent::class)
interface LyricsHelperEntryPoint {
    fun lyricsHelper(): LyricsHelper
    fun lyricsPreloadManager(): LyricsPreloadManager
}