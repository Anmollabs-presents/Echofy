/*
 * Echofy - by Anmol
 * Anmol Srivastava
 * Licensed Under GPL-3.0
 */



package com.anmol.echofy.constants

enum class HistorySource {
    LOCAL, REMOTE
}
