/*
 * Echofy - by Anmol
 * Anmol Srivastava
 * Licensed Under GPL-3.0
 */

package com.anmol.echofy.together

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences

object TogetherOnlineEndpoint {
    // Online Together feature is disabled in this build.
    // Use local (LAN) Together mode instead.
    private const val HTTP_URL = ""

    @Suppress("UNUSED_PARAMETER")
    fun baseUrlOrNull(
        dataStore: DataStore<Preferences>,
    ): String? {
        // Return null to disable online Together server
        return null
    }

    fun onlineWebSocketUrlOrNull(
        rawWsUrl: String,
        baseUrl: String,
    ): String? {
        // Disabled — no external server connected
        return null
    }
}
